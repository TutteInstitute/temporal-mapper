import temporalmapper.temporal_mapper as tm_main

TemporalMapper = tm_main.TemporalMapper
centroid_datamap = tm_main.centroid_datamap
time_semantic_plot = tm_main.time_semantic_plot
